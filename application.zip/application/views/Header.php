<div class="titleheader">
	
	<div class="links">
	Logout
	</div>
	<div class="links">
	Teacher
	</div>
</div>
	<div class="contents">
		<div class="side_bar">
			<a href="<?php echo base_url()?>coordinator/add_student">Add Student</a>
		</div>
