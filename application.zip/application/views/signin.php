<html>
<head>
This is the heading
</head>
<title>
Hai
</title>
<body>
<br>
The sign in was successfull                  <br><?php
       
	echo $this->session->userdata('user_name');
  ?>


</body>
</html>
