<html><head>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">

<title>Sudent Registration</title>
</head>

<body>
<form action="registation/student_registation" method="post" enctype="multipart/form-data" name="form1">
<table border="0" width="464">
  <caption>
  STUDENT REGISTRATION
    </caption>
  <tbody><tr>
    <td width="202">
      <label>First Name </label>    </td>
    <td width="282"><input id="fname" name="fname" type="text"></td>
  </tr>
  <tr>
    <td>
      <label>Last Name</label>      </td>
    <td>      <input id="lname" name="lname" type="text"></td></tr>
  <tr>
    <td height="36">Gender</td>
    <td>
      <input name="m" id="m" value="male" type="radio">
      Male
      <input name="m" id="m" value="female" type="radio">
      Female   </td>
  </tr>
  <tr>
    <td>
      <label>Dob</label>       </td>
    <td><select id="l1" name="l1">
      
    </select>
      <select id="l2" name="l2">
      </select>
      <select id="l3" name="l3">
      </select></td>
  </tr>
   <tr>
	 <td> <label>Address</label></td>
    <td><textarea id="sadd" name="sadd"></textarea></td>
  </tr>
  <tr>
    <td>
      <label>Nationality</label>      </td>
    <td><input id="nat" name="nat" type="text"></td>
  </tr>
  <tr>
    <td>Class</td>
    <td>
      <input id="class" name="class" type="text">    </td>
  </tr>
  <tr>
    <td>
      <label>Photo</label>     </td>
    <td>
      <input id="file2" name="photo" type="file"> </td>
  </tr>
  <tr>  </tr>
   <tr>
    <td>Father's Name </td>
    <td>
      <input id="fname" name="fname" type="text">   </td>
  </tr>
  <tr>
	 <td> <label>Address</label></td>
    <td><textarea id="fadd" name="fadd"></textarea></td>
  </tr>
   <tr>
    <td>
      <label>Phone</label>      </td>
    <td><input id="fph" name="fph" type="text"></td>
  </tr>
  <tr>
    <td>
      <label>Email</label></td>
    <td><input id="femail" name="femail" type="text"></td>
  </tr>
   <tr>
    <td>Mother's Name </td>
    <td>
      <input id="mname" name="mname" type="text">   </td>
  </tr>
  
	 <tr><td> <label>Address</label></td>
    <td><textarea id="madd" name="madd"></textarea></td>
  </tr>
  
   <tr>
    <td>
      <label>Phone</label>      </td>
    <td><input id="mph" name="mph" type="text"></td>
  </tr>
  <tr>
  
    <td>
      <label>Email</label></td>
    <td><input id="memail" name="memail" type="text"></td>
  </tr>
  <tr>
    <td>
     </td></tr><tr>
    <td>Guardian Name </td>
    <td>
      <input id="gua" name="gua" type="text">   </td>
  </tr>
  <tr>
    <td height="36"></td>
    <td>
      <input name="f" id="f" value="Father" type="radio">
      Father
      <input name="m" id="m" value="Mother" type="radio">
      Mother   </td>
  </tr>
  <tr>
    <td>
      <label>Relationship with student</label>      </td>
    <td><input id="rln" name="rln" type="text"></td>
  </tr>
  <tr>
	 <td> <label>Residential Address</label></td>
     <td><textarea id="add" name="add"></textarea></td>
  </tr>
  
  <tr>
	 <td> <label>Postal Address</label></td>
    <td><textarea id="padd" name="padd"></textarea></td>
  </tr>
  <tr>
    <td>
	</td></tr><tr>
    <td>
      <label>Mobile +91</label>      </td>
    <td><input id="ph" name="ph" type="text"></td>
  </tr>
  <tr>
    <td>
      <label>Res:</label>      </td>
    <td><input id="ph" name="ph" type="text"></td>
  </tr>
  <tr><td>
      <label>Email</label></td>
    <td><input id="email" name="email" type="text"></td>
  </tr>
  
  
  
         
  
  <tr>
  	<td></td>
    <td height="38"><input name="Submit1" value="Submit" type="submit">
    <input name="Submit2" value="Clear" type="reset"></td>
  </tr>
</tbody></table>
</form>


</body></html>
