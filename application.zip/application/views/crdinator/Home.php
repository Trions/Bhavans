		<?php $this->load->view('includes/Header.php');?>
		<?php $this->load->view('crdinator/Header.php');?>
		<div class="main_content">

				This is where the main contents for the home page goes




		</div>
	</div>

