<div class="titleheader">
	
	<div class="links">
	Logout
	</div>
	<div class="links">
	 List Teacher
	 </div>
</div>
	<div class="contents">
		<div class="side_bar">
			<div class="coordinator_sidebar">
					
			</div>
			<a href="<?php echo base_url()?>coordinator/add_student">Add Student</a>
			<a href="<?php echo base_url()?>coordinator/add_teacher">Add Teacher</a> 

		</div>
		
