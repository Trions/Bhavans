
<?php
	//$this->load->view('');

	$this->load->view($main_content);
	//$this->load->model('');
?>
