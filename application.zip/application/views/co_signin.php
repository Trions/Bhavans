<html>
<head>
Coordinator
</head>
<title>
Hai
</title>
<body>
<br>
Welcome                   <br><?php
       
	echo $this->session->userdata('user_name');
  ?>


</body>
</html>
